<?php

namespace Sifrious\AccountsClient;

use Illuminate\Http\Client\Factory;
use InvalidArgumentException;
use Sifrious\AccountsClient\Data\AccountReference;
use UnexpectedValueException;

/** Resolves a presented app token at the account host without storing credentials. */
final readonly class AccountTokenVerifier
{
    public function __construct(
        private Factory $http,
        private string $baseUrl,
        private string $product,
    ) {
        $url = parse_url($baseUrl);
        if (! is_array($url) || ($url['scheme'] ?? null) !== 'https' || ! isset($url['host'])
            || isset($url['user']) || isset($url['pass']) || isset($url['query']) || isset($url['fragment'])
            || ! in_array($url['path'] ?? '', ['', '/'], true) || $product === '') {
            throw new InvalidArgumentException('An HTTPS account origin and expected product are required.');
        }
    }

    public function verify(#[\SensitiveParameter] string $accessToken): AccountReference
    {
        if ($accessToken === '') {
            throw new InvalidArgumentException('An access token is required.');
        }
        $response = $this->http->baseUrl(rtrim($this->baseUrl, '/'))->acceptJson()
            ->withoutRedirecting()->connectTimeout(5)->timeout(15)->withToken($accessToken)
            ->get('/api/v1/me')->throw();
        $data = $response->json();
        if (! $response->successful() || ! is_array($data) || ($data['product'] ?? null) !== $this->product
            || ! is_array($data['account'] ?? null) || ! is_string($data['account']['id'] ?? null)
            || $data['account']['id'] === '' || strlen($data['account']['id']) > 255
            || ($data['account']['status'] ?? null) !== 'active') {
            throw new UnexpectedValueException('The server did not return an active account for this product.');
        }

        return new AccountReference($data['account']['id'], 'active', false);
    }
}
