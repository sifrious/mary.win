<?php

namespace Sifrious\AccountsClient;

use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\PendingRequest;
use InvalidArgumentException;
use Sifrious\AccountsClient\Data\AccountReference;
use Sifrious\AccountsClient\Data\AppCredentials;
use Sifrious\AccountsClient\Data\LoginAttempt;
use Sifrious\AccountsClient\Exceptions\LoginVerificationFailed;
use UnexpectedValueException;

final readonly class HostedAuthClient
{
    public function __construct(
        private Factory $http,
        private string $baseUrl,
        private string $clientId,
        private string $redirectUri,
        private string $product,
    ) {
        $url = parse_url($baseUrl);
        if (! is_array($url) || ($url['scheme'] ?? null) !== 'https' || ! isset($url['host'])
            || isset($url['user']) || isset($url['pass']) || isset($url['query']) || isset($url['fragment'])
            || ! in_array($url['path'] ?? '', ['', '/'], true)) {
            throw new InvalidArgumentException('The authentication server must be an HTTPS origin.');
        }
        if ($clientId === '' || $redirectUri === '' || $product === '' || str_contains($redirectUri, '?') || str_contains($redirectUri, '#')) {
            throw new InvalidArgumentException('A client, product, and exact registered return URI are required.');
        }
    }

    public function begin(): LoginAttempt
    {
        return new LoginAttempt($this->clientId, $this->redirectUri, bin2hex(random_bytes(32)), bin2hex(random_bytes(32)), time() + 600);
    }

    public function authorizationUrl(LoginAttempt $attempt): string
    {
        $this->assertOwnAttempt($attempt);
        return rtrim($this->baseUrl, '/').'/oauth/authorize?'.http_build_query([
            'client_id' => $this->clientId,
            'redirect_uri' => $this->redirectUri,
            'response_type' => 'code',
            'scope' => 'account:read',
            'state' => $attempt->state(),
            'code_challenge' => $attempt->challenge(),
            'code_challenge_method' => 'S256',
        ], '', '&', PHP_QUERY_RFC3986);
    }

    public function complete(#[\SensitiveParameter] string $callbackUri, LoginAttempt $attempt): AppCredentials
    {
        $this->assertOwnAttempt($attempt);
        if (str_contains($callbackUri, '#') || explode('?', $callbackUri, 2)[0] !== $this->redirectUri) {
            throw new LoginVerificationFailed('The callback does not match this app.');
        }
        parse_str(explode('?', $callbackUri, 2)[1] ?? '', $query);
        if (! is_string($query['state'] ?? null)) {
            throw new LoginVerificationFailed('Missing callback state.');
        }
        $verifier = $attempt->consume($query['state']);
        if (isset($query['error'])) {
            throw new LoginVerificationFailed('Authorization was declined.');
        }
        if (! is_string($query['code'] ?? null) || $query['code'] === '') {
            throw new LoginVerificationFailed('Missing authorization code.');
        }
        return $this->credentials($this->request()->asForm()->post('/oauth/token', [
            'grant_type' => 'authorization_code', 'client_id' => $this->clientId,
            'redirect_uri' => $this->redirectUri, 'code' => $query['code'], 'code_verifier' => $verifier,
        ])->throw()->json());
    }

    public function refresh(AppCredentials $credentials): AppCredentials
    {
        return $this->credentials($this->request()->asForm()->post('/oauth/token', [
            'grant_type' => 'refresh_token', 'client_id' => $this->clientId, 'refresh_token' => $credentials->refreshToken(),
        ])->throw()->json());
    }

    public function account(AppCredentials $credentials): AccountReference
    {
        return (new AccountTokenVerifier($this->http, $this->baseUrl, $this->product))
            ->verify($credentials->accessToken());
    }

    public function logout(AppCredentials $credentials): void
    {
        $this->request()->withToken($credentials->accessToken())->post('/api/v1/logout')->throw();
    }

    private function request(): PendingRequest
    {
        // Redirects must not send codes or credentials to a different origin.
        return $this->http->baseUrl(rtrim($this->baseUrl, '/'))->acceptJson()->withoutRedirecting()->timeout(15);
    }

    private function assertOwnAttempt(LoginAttempt $attempt): void
    {
        if ($attempt->clientId !== $this->clientId || $attempt->redirectUri !== $this->redirectUri) {
            throw new LoginVerificationFailed('Login belongs to a different client.');
        }
    }

    private function credentials(mixed $data): AppCredentials
    {
        if (! is_array($data) || ! is_string($data['token_type'] ?? null) || strcasecmp($data['token_type'], 'Bearer') !== 0
            || ! is_string($data['access_token'] ?? null) || $data['access_token'] === ''
            || ! is_string($data['refresh_token'] ?? null) || $data['refresh_token'] === ''
            || ! is_int($data['expires_in'] ?? null) || $data['expires_in'] <= 0) {
            throw new UnexpectedValueException('The server returned invalid app credentials.');
        }
        return new AppCredentials($data['access_token'], $data['refresh_token'], time() + $data['expires_in']);
    }
}
