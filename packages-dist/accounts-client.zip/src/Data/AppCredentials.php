<?php

namespace Sifrious\AccountsClient\Data;

final readonly class AppCredentials
{
    public function __construct(
        #[\SensitiveParameter] private string $accessToken,
        #[\SensitiveParameter] private string $refreshToken,
        public int $expiresAt,
    ) {}

    public function accessToken(): string
    {
        return $this->accessToken;
    }

    public function refreshToken(): string
    {
        return $this->refreshToken;
    }

    /** @return array{expiresAt: int} */
    public function __debugInfo(): array
    {
        return ['expiresAt' => $this->expiresAt];
    }
}
