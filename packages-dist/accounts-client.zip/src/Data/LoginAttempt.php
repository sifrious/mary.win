<?php

namespace Sifrious\AccountsClient\Data;

use Sifrious\AccountsClient\Exceptions\LoginVerificationFailed;

final class LoginAttempt
{
    private bool $consumed = false;

    public function __construct(
        public readonly string $clientId,
        public readonly string $redirectUri,
        #[\SensitiveParameter] private readonly string $state,
        #[\SensitiveParameter] private readonly string $verifier,
        public readonly int $expiresAt,
    ) {}

    public function challenge(): string
    {
        return rtrim(strtr(base64_encode(hash('sha256', $this->verifier, true)), '+/', '-_'), '=');
    }

    public function state(): string
    {
        return $this->state;
    }

    public function consume(#[\SensitiveParameter] string $state): string
    {
        if ($this->consumed || $this->expiresAt <= time() || ! hash_equals($this->state, $state)) {
            $this->consumed = true;
            throw new LoginVerificationFailed('Login expired, was already used, or has invalid state.');
        }
        $this->consumed = true;
        return $this->verifier;
    }

    /** @return array<string, string|int|bool> */
    public function __debugInfo(): array
    {
        return ['clientId' => $this->clientId, 'expiresAt' => $this->expiresAt, 'consumed' => $this->consumed];
    }
}
