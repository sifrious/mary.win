# Accounts Client

Copyright 2026 Sifrious. All rights reserved. This is publicly viewable proprietary software. See [LICENSE.md](LICENSE.md).

The client connects products to the authentication and account API hosted at mary.is. WorkOS is removed from this development version. Socialite runs on the host, not inside product applications.

`HostedAuthClient` is the public-client entry point for browser-to-app authorization. It needs the HTTPS host origin, a registered client ID, an exact return URI, and the expected product key. It never needs a provider secret or Zahir service credential.

Call `begin()` and open `authorizationUrl($attempt)` in the system browser. When the app receives its registered return URI, call `complete($uri, $attempt)`. The client verifies the return URI and state, consumes the transaction once, and exchanges the code with its PKCE verifier. `account($credentials)` verifies that the host returned the expected product and an active account. `refresh()` replaces the credentials after rotation. `logout()` revokes this account's connections for the app at the host.

The app owns the login attempt and credentials. Persist them only in platform secure storage if the app can restart during login. Clear the pending attempt after any callback and replace stored refresh credentials atomically after renewal. Never put either object into logs, URLs, analytics, unencrypted preferences, or game save files. Debug output omits their secrets, but that is not a substitute for secure storage. On a lost refresh response, require sign-in again rather than retrying a consumed refresh token indefinitely.

`AccountTokenVerifier` lets a product server resolve an incoming Bearer token at `/api/v1/me` without requiring a refresh token or OAuth client configuration. Construct it with the HTTP factory, HTTPS account origin, and expected product. `verify($token)` returns only a validated active account reference. Every verification calls the host so revocation takes effect on the next request. Redirects, inactive accounts, and a different product fail closed. The server must not log or persist the presented token. `HostedAuthClient::account()` uses the same verifier.

`AccountsClient` remains the confidential server-to-server client for account resolution, entitlement decisions, identity linking, and account lifecycle. Do not construct it in a downloadable app or distribute its service token.

## Compatibility

This development change removes the WorkOS driver and configuration. The provider-neutral `LoginDriver`, `LoginManager`, and `ProductAuthenticator` contracts remain for existing Laravel consumers, but the package no longer chooses or configures an identity provider. New native clients should use `HostedAuthClient`. Existing browser consumers should move provider callbacks to mary.is before adopting the hosted flow.

The provider-neutral consumer contract, Laravel middleware, test doubles, and conformance suite remain available. Applications that still use `LoginDriver` must bind their own implementation. The package does not provide a WorkOS implementation.

The library supplies protocol and HTTP behavior, not NativePHP views, deep-link registration, platform keychain integration, or product-local sessions. Those remain part of each app's integration.

Run `composer check` for unit tests, static analysis, and service-contract fixtures. The mary.is host also exercises this client against its real Passport routes in `tests/Feature/MobileAuthorizationTest.php` in that repository.

`bin/export-package.py` adds the `dev-main` version only to local development archives because Composer artifact repositories require explicit version metadata. Tagged source releases keep their version in Git rather than `composer.json`.
