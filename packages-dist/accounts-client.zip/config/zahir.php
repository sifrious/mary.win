<?php

/**
 * Publish with:
 *   php artisan vendor:publish --tag=zahir-config
 *
 * Every value here is deployment configuration. No secret belongs in source
 * control.
 */
return [
    'base_url' => env('ZAHIR_BASE_URL', 'http://localhost:8080'),
    'service_token' => env('ZAHIR_SERVICE_TOKEN'),

    // The product key and entitlement name this application asks Zahir about.
    // These are the application's own; never reuse another product's pair.
    'product' => env('ZAHIR_PRODUCT'),
    'access_entitlement' => env('ZAHIR_ACCESS_ENTITLEMENT', 'access'),

    // How stale a decision may be before a protected request re-asks. This is
    // the whole of the session-invalidation contract: suspension and revocation
    // take effect within this window without Zahir holding any session state.
    'entitlement_decision_max_age_seconds' => (int) env('ZAHIR_ENTITLEMENT_DECISION_MAX_AGE_SECONDS', 30),
];
